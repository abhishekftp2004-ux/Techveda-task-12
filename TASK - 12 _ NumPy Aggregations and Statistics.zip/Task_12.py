import numpy as np

# TASK 12 - NumPy Aggregations and Statistics

# 1. One-dimensional numerical data
data = np.array([60, 70, 80, 90, 100])

print("SUM:", np.sum(data))
print("MEAN:", np.mean(data))
print("MEDIAN:", np.median(data))
print("MINIMUM:", np.min(data))
print("MAXIMUM:", np.max(data))
print("STANDARD DEVIATION:", np.std(data))
print("VARIANCE:", np.var(data))

# 2. Student performance dataset
marks = np.array([
    [78, 82, 91],
    [65, 74, 80],
    [88, 90, 95],
    [55, 68, 72]
])

print("\nOVERALL STATISTICS")
print("Sum:", np.sum(marks))
print("Mean:", np.mean(marks))
print("Median:", np.median(marks))
print("Minimum:", np.min(marks))
print("Maximum:", np.max(marks))
print("Standard deviation:", np.std(marks))
print("Variance:", np.var(marks))

# 3. Axis operations
print("\nCOLUMN-WISE RESULTS (axis=0)")
print("Mean:", np.mean(marks, axis=0))
print("Minimum:", np.min(marks, axis=0))
print("Maximum:", np.max(marks, axis=0))

print("\nROW-WISE RESULTS (axis=1)")
print("Mean:", np.mean(marks, axis=1))
print("Total:", np.sum(marks, axis=1))

# 4. Short interpretation
print("\nINTERPRETATION")
print("Mean shows average performance.")
print("Median shows the middle value.")
print("Minimum and maximum show the range.")
print("Standard deviation and variance describe data spread.")
